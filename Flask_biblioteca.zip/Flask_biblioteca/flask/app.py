from flask import Flask
from flask_migrate import Migrate
from db import db
from models.book import Book



app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = (
    "postgresql://avnadmin:AVNS_S5VRJhowu8TLhcwAvD_@pg-32f5ee53-emillydrehmer043-c834.a.aivencloud.com:14985/defaultdb?sslmode=require"
)

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

migrate = Migrate(app, db)

@app.route("/hello", methods=["GET"])
def hello():
    return "API está funcionando!"

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=8080,
        debug=True
    )