CREATE DATABASE books;

use database books;